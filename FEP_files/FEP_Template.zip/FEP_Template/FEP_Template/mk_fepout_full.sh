#!/bin/bash

rm forward_full.fepout

cat output/0/forward.0.fepout > forward_full.fepout


for i in {1..19}

do

cat output/$i/forward.$i.fepout >> forward_full.fepout

done



rm backward_full.fepout

cat output/0/backward.0.fepout > backward_full.fepout


for i in {1..19}

do

cat output/$i/backward.$i.fepout >> backward_full.fepout

done



exit

